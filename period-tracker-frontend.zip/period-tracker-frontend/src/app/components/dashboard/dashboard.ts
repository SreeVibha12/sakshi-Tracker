import { Component, OnInit } from '@angular/core';
import { CommonModule, formatDate } from '@angular/common';
import { RouterLink } from '@angular/router';

import { PeriodService } from '../../services/period.service';
import { DailyService } from '../../services/daily.service';

import { Period, DailyLog } from '../../../models/interfaces';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css']
})
export class DashboardComponent implements OnInit {

  avgCycle = 28;
  nextPeriod = 'Loading...';
  lastPeriodDate = 'No recent period logged';

  recentPeriods: Period[] = [];
  dailyLogs: DailyLog[] = [];

  insights = [
    'Cycle looks regular',
    'Log your daily water & sleep'
  ];

  constructor(
    private periodService: PeriodService,
    private dailyService: DailyService
  ) {}

  ngOnInit(): void {
    console.log('DashboardComponent initialized');
    this.loadDashboard();
  }

 loadDashboard(): void {

  this.periodService.getPredictions().subscribe({
    next: (data) => {
      console.log('Prediction:', data);

      this.avgCycle = data.avgCycle;
      this.nextPeriod = data.nextPeriod;
    }
  });

  this.periodService.getPeriods().subscribe({
    next: (periods) => {

      console.log('Periods:', periods);

      this.recentPeriods = [...periods];

      this.lastPeriodDate =
        periods.length
          ? formatDate(periods[0].startDate, 'longDate', 'en-US')
          : 'No recent period logged';

      console.log('recentPeriods after assign:', this.recentPeriods);
      console.log('lastPeriodDate:', this.lastPeriodDate);

    }
  });

  // 👇 TEMPORARILY COMMENT THIS OUT
  /*
  this.dailyService.getLogs().subscribe({
    next: logs => {
      this.dailyLogs = logs;
    }
  });
  */

}

}